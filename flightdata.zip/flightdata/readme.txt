soubory let[cislo]_[osa].txt obsahuji data namerena navrzenym systemem tedy polohy v metrech, oproti surovym datum byla aplikovana rotace a inverze osy x, tak aby osy souhlasily s daty namerenymi gps
soubory let[cislo]_[osa]_gps.txt obsahuji gps data gps prevedena na souradnice v metrech

data v obou typech souboru jsou posunuta tak, aby zobrazena cast mereni zacinala v bode [0,0,0]

soubory
gps_[osa]_raw.txt obsahuji nezpracovana gps data vsech letu